# 191 Manager V3
ضع الملفات الثلاثة في جذر GitHub Repository:
index.html
manifest.webmanifest
sw.js

GitHub Pages:
Settings > Pages > Deploy from a branch > main > /(root) > Save.
ثم افتح الرابط في Safari > Share > Add to Home Screen.

البرنامج يحفظ البيانات محليا في المتصفح، ويحسب تكلفة الوصفة تلقائيا ويخصم المواد الخام عند البيع.
هذه نسخة أولية لجهاز واحد؛ النسخة السحابية متعددة المستخدمين تحتاج قاعدة بيانات ومصادقة.

## حماية البيانات
- يحفظ التطبيق تلقائيا آخر 20 حالة قبل التعديلات.
- يوجد زر "Annuler la dernière modification" للرجوع.
- يوجد "Historique / récupérer" لاختيار نسخة سابقة.
- النسخة الاحتياطية JSON تحتوي البيانات وسجل الاسترجاع.
- يفضّل تصدير نسخة احتياطية يوميا قبل إغلاق المحل.
